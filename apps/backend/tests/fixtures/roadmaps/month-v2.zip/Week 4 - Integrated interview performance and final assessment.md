# Week 4

## Month 1 exit criteria

- Explain one integration clearly.
- Score at least 4 independently.

## Day 24 — Month 1 final assessment — 2 hours
## Day 23 — Dress rehearsal and final behavioral assessment
## Day 22 — Cross-functional conflict
## Day 21 — QBR-lite and executive narrative
## Day 20 — Launch judgment under pressure
## Day 19 — TAM-adapted payment-system design
