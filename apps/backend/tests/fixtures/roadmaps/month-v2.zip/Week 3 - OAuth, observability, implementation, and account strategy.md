# Week 3

## Day 18 — Week 3 assessment — 2 hours
## Day 17 — Technical account strategy
## Day 16 — Implementation planning
## Day 15 — Logs, metrics, traces, and SLOs
## Day 14 — PKCE, webhook verification, and security failures
## Day 13 — OAuth fundamentals
