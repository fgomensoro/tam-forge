# Synthetic Month 1

## Resources

- [[templates/scorecard|Daily scorecard]]
- [OAuth reference](https://example.com/oauth)
- [[sql/tasks|SQL tasks]]
- [HTTP reference](https://example.com/http)
