# Week 2

## Day 12 — Week 2 assessment — 2 hours
## Day 11 — Postmortem and business value
## Day 10 — Incident command
## Day 9 — Payment lifecycle
## Day 8 — Circuit breakers, DLQs, and backlog control
## Day 7 — Timeouts, retries, and indeterminate outcomes
