# Week 2

## Day 7 — Timeouts, retries, and indeterminate outcomes

Practice Day 7.

## Day 8 — Circuit breakers, DLQs, and backlog control

Practice Day 8.

## Day 9 — Payment lifecycle

Practice Day 9.

## Day 10 — Incident command

Practice Day 10.

## Day 11 — Postmortem and business value

Practice Day 11.

## Day 12 — Week 2 assessment — 2 hours

Assess Week 2.
