# Week 4

## Day 19 — TAM-adapted payment-system design

Practice Day 19.

## Day 20 — Launch judgment under pressure

Practice Day 20.

## Day 21 — QBR-lite and executive narrative

Practice Day 21.

## Day 22 — Cross-functional conflict

Practice Day 22.

## Day 23 — Dress rehearsal and final behavioral assessment

Practice Day 23.

## Day 24 — Month 1 final assessment — 2 hours

Assess Month 1.

## Month 1 exit criteria

- Score at least 3 independently.
- Explain one integration clearly.
