# Daily scorecard

Record the strongest evidence.
