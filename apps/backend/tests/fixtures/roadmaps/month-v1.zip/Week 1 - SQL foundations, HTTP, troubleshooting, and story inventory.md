# Week 1

## Day 1 — Baseline and HTTP

Practice Day 1.

## Day 2 — Joins and diagnostic questions

Practice Day 2.

## Day 3 — Aggregation, idempotency, and audience switching

Practice Day 3.

## Day 4 — Webhooks, rate limits, and incident writing

Practice Day 4.

## Day 5 — Discovery and first complete behavioral story

Practice Day 5.

## Day 6 — Week 1 assessment — 2 hours

Assess Week 1.
