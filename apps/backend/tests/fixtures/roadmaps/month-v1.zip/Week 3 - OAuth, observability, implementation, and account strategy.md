# Week 3

## Day 13 — OAuth fundamentals

Practice Day 13.

## Day 14 — PKCE, webhook verification, and security failures

Practice Day 14.

## Day 15 — Logs, metrics, traces, and SLOs

Practice Day 15.

## Day 16 — Implementation planning

Practice Day 16.

## Day 17 — Technical account strategy

Practice Day 17.

## Day 18 — Week 3 assessment — 2 hours

Assess Week 3.
