# SQL tasks

Complete one reconciliation query.
