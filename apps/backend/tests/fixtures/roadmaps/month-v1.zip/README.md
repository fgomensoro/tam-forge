# Synthetic Month 1

## Resources

- [HTTP reference](https://example.com/http)
- [[sql/tasks|SQL tasks]]
- [[templates/scorecard|Daily scorecard]]
